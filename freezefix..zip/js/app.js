/* js/app.js — Core Controller & UI Binder */
'use strict';

document.addEventListener('DOMContentLoaded', () => {
    // ── Elements ──
    const elClock         = document.getElementById('clock');
    const elClockDate     = document.getElementById('clock-date');
    const elGreeting      = document.getElementById('greeting');
    const elTodayLabel    = document.getElementById('today-label');
    const elTimeline      = document.getElementById('timeline');
    const elTaskList      = document.getElementById('task-list');
    const elWeekGrid      = document.getElementById('week-grid');

    const elNextName      = document.getElementById('next-task-name');
    const elNextMeta      = document.getElementById('next-task-meta');
    const elBtnStartFocus = document.getElementById('btn-start-focus');
    const elBtnMarkDone   = document.getElementById('btn-mark-done');
    const elBtnGoodEnough = document.getElementById('btn-good-enough');
    const elBtnSkipTask   = document.getElementById('btn-skip-task');

    const elTimerDisplay  = document.getElementById('timer-display');
    const elTimerLabel    = document.getElementById('timer-label');
    const elTimerProgress = document.getElementById('timer-ring-progress');
    const elBtnTimerToggle= document.getElementById('btn-timer-toggle');
    const elBtnTimerReset = document.getElementById('btn-timer-reset');

    const elBrainInput    = document.getElementById('brain-dump-input');
    const elBtnBrainAdd   = document.getElementById('btn-brain-add');
    const elBtnWhatsNext  = document.getElementById('btn-whats-next');
    const elAiResponse    = document.getElementById('ai-response');

    const elStreakNum     = document.getElementById('streak-num');
    const elDoneToday     = document.getElementById('done-today');
    const elTasksLeft     = document.getElementById('tasks-left');

    const elModalTask     = document.getElementById('modal-task');
    const elTaskForm      = document.getElementById('task-form');
    const elModalBreakdown= document.getElementById('modal-breakdown');
    const elModalSettings = document.getElementById('modal-settings');
    const elModalHistory  = document.getElementById('modal-history');

    // ── State ──
    let activeFilter = 'pending';
    let currentFocusTask = null;
    let timerMins = 25;
    let timerSecsLeft = 25 * 60;
    let timerTotalSecs = 25 * 60;
    let timerInterval = null;
    let isTimerRunning = false;
    let currentBreakdownSteps = [];
    let currentBreakdownTaskName = '';

    // ── Initialization ──
    initClock();
    renderAll();
    setInterval(updateClock, 1000);
    setInterval(renderTimelineNowLine, 60000);

    // ── Clock & Greetings ──
    function initClock() {
        updateClock();
        const now = new Date();
        elTodayLabel.textContent = now.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' });
    }

    function updateClock() {
        const now = new Date();
        const hrs = String(now.getHours()).padStart(2, '0');
        const mins = String(now.getMinutes()).padStart(2, '0');
        elClock.textContent = `${hrs}:${mins}`;
        elClockDate.textContent = now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

        const hour = now.getHours();
        let greeting = '🌙 Rest up & unwind';
        if (hour >= 5 && hour < 12) greeting = '🌅 Good morning! Ready for a fresh start?';
        else if (hour >= 12 && hour < 17) greeting = '☀️ Good afternoon! Stay in your flow';
        else if (hour >= 17 && hour < 22) greeting = '🌆 Evening session — wrap up strong';
        elGreeting.textContent = greeting;
    }

    // ── Render Controller ──
    function renderAll() {
        const pending = TaskManager.getPending();
        const allTasks = TaskManager.getAll();

        renderTimeline(allTasks);
        renderTaskList();
        renderWeekGrid();
        renderNextTaskCard();
        renderStats();
    }

    // ── Timeline Rendering ──
    function renderTimeline(tasks) {
        elTimeline.innerHTML = '';
        const startHour = 7;
        const endHour = 22;
        const totalHours = endHour - startHour;
        const hourHeight = 44;
        elTimeline.style.height = `${totalHours * hourHeight}px`;

        // Render Hour lines & labels
        for (let i = 0; i <= totalHours; i++) {
            const h = startHour + i;
            const y = i * hourHeight;

            const lbl = document.createElement('div');
            lbl.className = 'time-label';
            lbl.style.top = `${y - 6}px`;
            lbl.textContent = `${h % 12 || 12}${h >= 12 ? 'p' : 'a'}`;
            elTimeline.appendChild(lbl);

            const line = document.createElement('div');
            line.className = 'hour-line';
            line.style.top = `${y}px`;
            elTimeline.appendChild(line);
        }

        renderTimelineNowLine();

        // Render Scheduled Tasks
        const scheduled = tasks.filter(t => t.scheduledStart && t.scheduledEnd);
        scheduled.forEach(task => {
            const s = new Date(task.scheduledStart);
            const e = new Date(task.scheduledEnd);

            const startMins = s.getHours() * 60 + s.getMinutes();
            const endMins = e.getHours() * 60 + e.getMinutes();

            const topY = ((startMins - startHour * 60) / 60) * hourHeight;
            const height = Math.max(22, ((endMins - startMins) / 60) * hourHeight);

            if (topY >= 0 && topY <= totalHours * hourHeight) {
                const block = document.createElement('div');
                block.className = `task-block ${task.overdue ? 'overdue' : ''}`;
                block.dataset.cat = task.category;
                block.style.top = `${topY}px`;
                block.style.height = `${height}px`;

                block.innerHTML = `
                    <div class="task-block-name">${task.name}</div>
                    <div class="task-block-dur">${task.duration}m</div>
                `;
                block.title = `${task.name} (${s.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} - ${e.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})})`;
                block.onclick = () => openEditTaskModal(task);
                elTimeline.appendChild(block);
            }
        });
    }

    function renderTimelineNowLine() {
        const existing = elTimeline.querySelector('.time-now-line');
        if (existing) existing.remove();

        const now = new Date();
        const startHour = 7;
        const hourHeight = 44;
        const mins = now.getHours() * 60 + now.getMinutes();
        const y = ((mins - startHour * 60) / 60) * hourHeight;

        if (y >= 0 && y <= (22 - startHour) * hourHeight) {
            const line = document.createElement('div');
            line.className = 'time-now-line';
            line.style.top = `${y}px`;
            elTimeline.appendChild(line);
        }
    }

    // ── Task List Rendering ──
    function renderTaskList() {
        elTaskList.innerHTML = '';
        let list = [];
        if (activeFilter === 'pending') list = TaskManager.getPending();
        else if (activeFilter === 'today') list = TaskManager.getTodayScheduled();
        else list = TaskManager.getAll();

        if (list.length === 0) {
            elTaskList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">✨</div>
                    <div>No tasks here right now!</div>
                </div>`;
            return;
        }

        list.forEach(task => {
            const item = document.createElement('div');
            item.className = `task-item ${task.completed ? 'completed' : ''} ${task.overdue ? 'overdue' : ''}`;
            item.dataset.cat = task.category;

            const catInfo = TaskManager.CATEGORIES[task.category] || TaskManager.CATEGORIES.other;
            const priInfo = TaskManager.PRIORITIES[task.priority] || TaskManager.PRIORITIES[3];

            item.innerHTML = `
                <div class="task-check ${task.completed ? 'checked' : ''}" onclick="event.stopPropagation(); toggleComplete(${task.id})">
                    ${task.completed ? '✓' : ''}
                </div>
                <div class="task-content">
                    <div class="task-name">${task.name}</div>
                    <div class="task-meta">
                        <span class="task-cat cat-${task.category}">${catInfo.icon} ${catInfo.label}</span>
                        <span class="task-pri">${priInfo.icon}</span>
                        <span class="task-dur">⏱ ${task.duration}m</span>
                    </div>
                </div>
                <div class="task-actions">
                    <button class="icon-btn" title="Magic Breakdown" onclick="event.stopPropagation(); startBreakdown(${task.id})">🪄</button>
                    <button class="icon-btn" title="Edit" onclick="event.stopPropagation(); openEditTaskModalById(${task.id})">✏️</button>
                    <button class="icon-btn" title="Delete" onclick="event.stopPropagation(); deleteTask(${task.id})">🗑</button>
                </div>
            `;
            item.onclick = () => openEditTaskModal(task);
            elTaskList.appendChild(item);
        });
    }

    // ── Week Grid Rendering ──
    function renderWeekGrid() {
        elWeekGrid.innerHTML = '';
        const summary = HistoryManager.getWeeklySummary();
        summary.forEach(day => {
            const cell = document.createElement('div');
            cell.className = `week-day ${day.isToday ? 'today' : ''}`;
            cell.innerHTML = `
                <div class="week-day-label">${day.label}</div>
                <div class="week-day-num">${day.date.getDate()}</div>
                <div class="week-dots">
                    ${Array.from({ length: Math.min(5, day.count) }).map(() => `<span class="dot dot-done">●</span>`).join('')}
                </div>
            `;
            elWeekGrid.appendChild(cell);
        });
    }

    // ── Next Task Card ──
    function renderNextTaskCard() {
        const pending = TaskManager.getPending();
        currentFocusTask = Scheduler.getCurrentTask(pending);

        if (!currentFocusTask) {
            elNextName.textContent = "🎉 All done! Ready for a break or a new task.";
            elNextMeta.textContent = "";
            elBtnStartFocus.style.display = "none";
            elBtnMarkDone.style.display = "none";
            elBtnGoodEnough.style.display = "none";
            elBtnSkipTask.style.display = "none";
            return;
        }

        elNextName.textContent = currentFocusTask.name;
        const catInfo = TaskManager.CATEGORIES[currentFocusTask.category] || TaskManager.CATEGORIES.other;
        elNextMeta.textContent = `${catInfo.icon} ${catInfo.label} • ⏱ ${currentFocusTask.duration} minutes`;

        elBtnStartFocus.style.display = "inline-flex";
        elBtnMarkDone.style.display = "inline-flex";
        elBtnGoodEnough.style.display = "inline-flex";
        elBtnSkipTask.style.display = "inline-flex";
    }

    // ── Stats Bar ──
    function renderStats() {
        elStreakNum.textContent = HistoryManager.getStreak();
        elDoneToday.textContent = HistoryManager.getCompletedToday();
        elTasksLeft.textContent = TaskManager.getPending().length;
    }

    // ── Global Actions ──
    window.toggleComplete = function(id) {
        const task = TaskManager.getById(id);
        if (!task) return;
        if (!task.completed) {
            TaskManager.complete(id);
            HistoryManager.logCompletion(task);
            triggerCelebration(task.name);
        } else {
            TaskManager.update(id, { completed: false, completedAt: null });
        }
        renderAll();
    };

    window.deleteTask = function(id) {
        TaskManager.remove(id);
        showToast('Task removed');
        renderAll();
    };

    window.openEditTaskModalById = function(id) {
        const t = TaskManager.getById(id);
        if (t) openEditTaskModal(t);
    };

    function openEditTaskModal(task = null) {
        document.getElementById('task-modal-title').textContent = task ? 'Edit Task' : 'Add Task';
        elTaskForm.reset();
        elTaskForm.dataset.editId = task ? task.id : '';

        if (task) {
            document.getElementById('tf-name').value = task.name;
            document.getElementById('tf-duration').value = task.duration;
            document.getElementById('tf-priority').value = task.priority;
            document.getElementById('tf-category').value = task.category;
            document.getElementById('tf-deadline').value = task.deadline || '';
            document.getElementById('tf-scheduled').value = task.scheduledStart || '';
            document.getElementById('tf-notes').value = task.notes || '';
        }
        elModalTask.classList.remove('hidden');
    }

    // ── Form Submissions ──
    elTaskForm.onsubmit = (e) => {
        e.preventDefault();
        const editId = elTaskForm.dataset.editId;
        const data = {
            name: document.getElementById('tf-name').value,
            duration: parseInt(document.getElementById('tf-duration').value || 30),
            priority: parseInt(document.getElementById('tf-priority').value || 3),
            category: document.getElementById('tf-category').value,
            deadline: document.getElementById('tf-deadline').value || null,
            scheduledStart: document.getElementById('tf-scheduled').value || null,
            notes: document.getElementById('tf-notes').value,
        };

        if (editId) {
            TaskManager.update(parseInt(editId), data);
            showToast('Task updated');
        } else {
            TaskManager.create(data);
            showToast('Task added! 🎯');
        }

        elModalTask.classList.add('hidden');
        renderAll();
    };

    // ── Brain Dump ──
    function handleBrainDump() {
        const text = elBrainInput.value.trim();
        if (!text) return;
        TaskManager.create({ name: text, duration: 20, priority: 3 });
        elBrainInput.value = '';
        showToast('Dumped into tasks! ⚡');
        renderAll();
    }
    elBtnBrainAdd.onclick = handleBrainDump;
    elBrainInput.onkeydown = (e) => { if (e.key === 'Enter') handleBrainDump(); };

    // ── Auto Scheduler ──
    document.getElementById('btn-auto-schedule').onclick = () => {
        const pending = TaskManager.getPending();
        const scheduled = Scheduler.autoSchedule(pending);
        scheduled.forEach(t => TaskManager.update(t.id, { scheduledStart: t.scheduledStart, scheduledEnd: t.scheduledEnd }));
        showToast('Auto-scheduled all tasks! ⚡');
        renderAll();
    };

    document.getElementById('btn-reschedule').onclick = () => {
        const pending = TaskManager.getPending();
        const checked = Scheduler.checkOverdue(pending);
        const overdueTasks = checked.filter(t => t.overdue);
        if (!overdueTasks.length) {
            showToast('No overdue tasks to reschedule! ✨');
            return;
        }
        const rescheduled = Scheduler.autoSchedule(overdueTasks);
        rescheduled.forEach(t => TaskManager.update(t.id, { scheduledStart: t.scheduledStart, scheduledEnd: t.scheduledEnd, overdue: false }));
        showToast('Overdue tasks rescheduled forward 🔄');
        renderAll();
    };

    // ── Focus & Timer Controls ──
    elBtnStartFocus.onclick = () => {
        if (!currentFocusTask) return;
        setTimerMinutes(currentFocusTask.duration);
        startTimer();
        showToast(`Focus mode started for "${currentFocusTask.name}" 🎯`);
    };

    elBtnMarkDone.onclick = () => {
        if (!currentFocusTask) return;
        toggleComplete(currentFocusTask.id);
    };

    elBtnGoodEnough.onclick = () => {
        if (!currentFocusTask) return;
        showToast('👍 "Good Enough" is finished! Progress logged.');
        toggleComplete(currentFocusTask.id);
    };

    elBtnSkipTask.onclick = () => {
        showToast('Skipped to next task →');
        renderAll();
    };

    // ── Timer Logic ──
    function setTimerMinutes(mins) {
        timerMins = mins;
        timerTotalSecs = mins * 60;
        timerSecsLeft = timerTotalSecs;
        updateTimerDisplay();
    }

    function updateTimerDisplay() {
        const m = String(Math.floor(timerSecsLeft / 60)).padStart(2, '0');
        const s = String(timerSecsLeft % 60).padStart(2, '0');
        elTimerDisplay.textContent = `${m}:${s}`;

        const circumference = 2 * Math.PI * 52;
        const offset = circumference - (timerSecsLeft / timerTotalSecs) * circumference;
        elTimerProgress.style.strokeDasharray = circumference;
        elTimerProgress.style.strokeDashoffset = offset;
    }

    function startTimer() {
        if (isTimerRunning) return;
        isTimerRunning = true;
        elBtnTimerToggle.textContent = '⏸';
        timerInterval = setInterval(() => {
            if (timerSecsLeft > 0) {
                timerSecsLeft--;
                updateTimerDisplay();
            } else {
                pauseTimer();
                showToast('🔔 Time is up! Great work!');
            }
        }, 1000);
    }

    function pauseTimer() {
        isTimerRunning = false;
        elBtnTimerToggle.textContent = '▶';
        clearInterval(timerInterval);
    }

    elBtnTimerToggle.onclick = () => {
        if (isTimerRunning) pauseTimer();
        else startTimer();
    };

    elBtnTimerReset.onclick = () => {
        pauseTimer();
        timerSecsLeft = timerTotalSecs;
        updateTimerDisplay();
    };

    document.querySelectorAll('.mode-chip').forEach(chip => {
        chip.onclick = () => {
            document.querySelectorAll('.mode-chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            const mins = parseInt(chip.dataset.min);
            elTimerLabel.textContent = chip.dataset.label;
            pauseTimer();
            setTimerMinutes(mins);
        };
    });

    // ── Breakdown Modal & AI ──
    window.startBreakdown = async function(id) {
        const task = TaskManager.getById(id);
        if (!task) return;
        currentBreakdownTaskName = task.name;
        document.getElementById('breakdown-task-title').textContent = `Task: ${task.name}`;
        const elList = document.getElementById('breakdown-steps');
        const elLoading = document.getElementById('breakdown-loading');

        elList.innerHTML = '';
        elLoading.classList.remove('hidden');
        elModalBreakdown.classList.remove('hidden');

        currentBreakdownSteps = await AIHelper.generateTaskBreakdown(task.name);
        elLoading.classList.add('hidden');

        renderBreakdownSteps();
    };

    function renderBreakdownSteps() {
        const elList = document.getElementById('breakdown-steps');
        elList.innerHTML = '';
        currentBreakdownSteps.forEach((step, idx) => {
            const item = document.createElement('div');
            item.className = 'breakdown-step';
            item.innerHTML = `
                <div class="step-num">${idx + 1}</div>
                <div style="flex:1">
                    <div class="step-name">${step.name}</div>
                    <div class="step-duration">⏱ ${step.duration} mins</div>
                </div>
            `;
            elList.appendChild(item);
        });
    }

    document.getElementById('btn-breakdown-add-all').onclick = () => {
        currentBreakdownSteps.forEach(step => {
            TaskManager.create({ name: step.name, duration: step.duration, category: 'work', priority: 3 });
        });
        elModalBreakdown.classList.add('hidden');
        showToast(`Added ${currentBreakdownSteps.length} micro-steps! 🪄`);
        renderAll();
    };

    elBtnWhatsNext.onclick = async () => {
        elAiResponse.classList.remove('hidden');
        elAiResponse.textContent = "Thinking...";
        const advice = await AIHelper.suggestNextTask(TaskManager.getPending(), HistoryManager.getStreak());
        elAiResponse.innerHTML = advice.replace(/\n/g, '<br>');
    };

    // ── Filters & Modals ──
    document.querySelectorAll('#task-filters .chip').forEach(chip => {
        chip.onclick = () => {
            document.querySelectorAll('#task-filters .chip').forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            activeFilter = chip.dataset.filter;
            renderTaskList();
        };
    });

    document.querySelectorAll('[data-close]').forEach(btn => {
        btn.onclick = () => {
            document.getElementById(btn.dataset.close).classList.add('hidden');
        };
    });

    document.getElementById('btn-add-task').onclick = () => openEditTaskModal();
    document.getElementById('btn-add-block').onclick = () => openEditTaskModal();

    // ── Toast & Celebration ──
    function showToast(msg) {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.classList.remove('hidden');
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.classList.add('hidden'), 300);
        }, 3000);
    }

    function triggerCelebration(taskName) {
        const overlay = document.getElementById('celebration-overlay');
        const msg = document.getElementById('celebration-message');
        const container = document.getElementById('confetti-container');

        const phrases = ['BOOM! Task Crushed! 🔥', 'Dopamine Unlocked! ✨', 'You Are Unstoppable! 🚀', 'Awesome Work! 🌟'];
        msg.textContent = `${phrases[Math.floor(Math.random() * phrases.length)]}\n"${taskName}"`;

        container.innerHTML = '';
        for (let i = 0; i < 40; i++) {
            const p = document.createElement('div');
            p.className = 'confetti-piece';
            p.style.left = `${Math.random() * 100}%`;
            p.style.backgroundColor = ['#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#f43f5e'][Math.floor(Math.random() * 5)];
            p.style.width = `${Math.random() * 8 + 6}px`;
            p.style.height = `${Math.random() * 14 + 8}px`;
            p.style.animationDuration = `${Math.random() * 2 + 1.5}s`;
            p.style.setProperty('--drift', `${(Math.random() - 0.5) * 200}px`);
            container.appendChild(p);
        }

        overlay.classList.remove('hidden');
        setTimeout(() => overlay.classList.add('hidden'), 2500);
    }

    // ── Google Calendar .ics Import ──
    const fileInput = document.getElementById('ics-input');
    document.getElementById('btn-import-cal').onclick = () => fileInput.click();
    fileInput.onchange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
            const parsed = ICSParser.parseICS(evt.target.result);
            parsed.forEach(t => TaskManager.create(t));
            showToast(`Imported ${parsed.length} events from Calendar! 📅`);
            renderAll();
        };
        reader.readAsText(file);
    };

    // ── Settings & Backup ──
    document.getElementById('btn-settings').onclick = () => {
        const s = JSON.parse(localStorage.getItem('adhd_settings') || '{}');
        document.getElementById('sf-gemini-key').value = s.geminiKey || '';
        document.getElementById('sf-groq-key').value = s.groqKey || '';
        document.getElementById('sf-gcal-url').value = s.gcalUrl || '';
        document.getElementById('sf-work-start').value = s.workStart || '09:00';
        document.getElementById('sf-work-end').value = s.workEnd || '18:00';
        document.getElementById('sf-break-mins').value = s.breakMins || '15';
        elModalSettings.classList.remove('hidden');
    };

    document.getElementById('btn-save-settings').onclick = () => {
        const s = {
            geminiKey: document.getElementById('sf-gemini-key').value.trim(),
            groqKey: document.getElementById('sf-groq-key').value.trim(),
            gcalUrl: document.getElementById('sf-gcal-url').value.trim(),
            workStart: document.getElementById('sf-work-start').value,
            workEnd: document.getElementById('sf-work-end').value,
            breakMins: document.getElementById('sf-break-mins').value,
        };
        localStorage.setItem('adhd_settings', JSON.stringify(s));
        elModalSettings.classList.add('hidden');
        showToast('Settings saved!');
        renderAll();
    };

    document.getElementById('btn-save-sync').onclick = () => {
        const jsonStr = TaskManager.exportJSON();
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `adhd-flow-backup-${new Date().toISOString().slice(0,10)}.json`;
        a.click();
        showToast('Backup downloaded! 💾');
    };

    const jsonLoadInput = document.getElementById('json-load-input');
    document.getElementById('btn-load-sync').onclick = () => jsonLoadInput.click();
    jsonLoadInput.onchange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
            if (TaskManager.importJSON(evt.target.result)) {
                showToast('Backup restored successfully! 📂');
                renderAll();
            } else {
                showToast('Failed to parse backup file');
            }
        };
        reader.readAsText(file);
    };
});
